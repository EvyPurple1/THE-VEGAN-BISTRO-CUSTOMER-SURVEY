# THE-VEGAN-BISTRO-CUSTOMER-SURVEY
Customer survey after visiting the Vegan Bistro
